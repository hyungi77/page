import numberImg1 from "@assets/images/icons/participate-image.png"
import numberImg2 from "@assets/images/icons/participate-image2.png"
import numberImg3 from "@assets/images/icons/participate-image3.png"

const data = [
    {
        icon: numberImg1,
        title: "Submit KYC",
        text: "Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece"
    },
    {
        icon: numberImg2,
        title: "Verify Wallet",
        text: "Popular belief Ipsum is not simply random text. It has roots in a piece of classical"
    },
    {
        icon: numberImg3,
        title: "Start Staking",
        text: "Belief norem Isum is not simply random text. It has roots in a piece of classical"
    },
]

export default data;