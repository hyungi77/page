const data = [
  {
    title: "MARKET CAP",
    value: "490.88",
    suffix: "M",
  },
  {
    title: "TVL",
    value: "38.60",
    suffix: "M",
  },
  {
    title: "PRICE",
    value: "0.09",
    suffix: "",
  },
  {
    title: "FUND RAISED",
    value: "160",
    suffix: "M",
  },
];

export default data;
