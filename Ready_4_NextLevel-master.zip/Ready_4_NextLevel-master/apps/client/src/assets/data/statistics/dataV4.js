
const data = [
    {
        title: "Farming Pool",
        value: "29.8%"
    },
    {
        title: "Private Sale",
        value: "25.00%"
    },
    {
        title: "Staking",
        value: "14.50%"
    },
    {
        title: "Liquidity",
        value: "12.00%"
    },
    {
        title: "Ecosystem",
        value: "10.50%"
    },
    {
        title: "Advisors",
        value: "8.00%"
    },
    {
        title: "Marketing",
        value: "13.05%"
    },
    {
        title: "Team",
        value: "5.80%"
    },
]

export default data;