const data = [ 
  {
    id: "2ZYYU",
    title: "Projects",
    url: "#",
    subMenus: [
      {
        id: "43X1V",
        title: "L4NL",
        url: "/projects-grid",
      }
    ],
  }
];

export default data;
