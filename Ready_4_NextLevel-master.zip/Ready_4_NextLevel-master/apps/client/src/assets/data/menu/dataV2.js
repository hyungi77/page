const data = [
  {
    title: "Project Summary",
    url: "#projectSummary",
  },
  {
    title: "Schedule",
    url: "#schedule",
  },
  {
    title: "Comparison",
    url: "#comparison",
  },
  {
    title: "Tokenomics",
    url: "#tokenomics",
  },
  {
    title: "Roadmap",
    url: "#roadmap",
  },
  {
    title: "Team Member",
    url: "#team",
  },
  {
    title: "Investors",
    url: "#investors",
  },
];

export default data;
