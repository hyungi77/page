module.exports = {
    siteTitle: "GamFi - Metaverse Web3 IGO/IDO Token Launchpad Next js Template",
    description: "GamFi – Metaverse Web3.0 IGO/IDO Gaming launchpad next js Template is a gaming Crypto token launching platform, It’s Included Live IGO/IEO/IDO/INO Project, Staking, Firming Pools, IGO game Landing.", 
    social: {
        twitter: "#"
    }
}