import { SectionTitle, SectionTitleWrapper } from "./SectionTitle";

export { SectionTitle, SectionTitleWrapper };
