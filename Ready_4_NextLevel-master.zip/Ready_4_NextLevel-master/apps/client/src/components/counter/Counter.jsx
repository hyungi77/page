import React, { useState } from "react"; 
import VisibilitySensor from "react-visibility-sensor";

const Counter = ({ className, ...rest }) => {
  const [viewPortEntered, setViewPortEntered] = useState(false);

  return (
     <></>
  );
};

export default Counter;