import StatisticsCounter from "./Count";

export default StatisticsCounter;
