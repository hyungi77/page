import Token from "./Token";

export default Token;
