import ProjectClassic from "./ProjectClassic";

export default ProjectClassic;