import styled from "styled-components";

const ComparisonStyleWrapper = styled.div`
  margin-top: 55px;
  .widget_title {
    margin-bottom: 15px;
  }
`;

export default ComparisonStyleWrapper;
