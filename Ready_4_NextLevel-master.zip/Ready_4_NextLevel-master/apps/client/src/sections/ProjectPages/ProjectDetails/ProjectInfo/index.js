import ProjectInfo from "./ProjectInfo";

export default ProjectInfo;