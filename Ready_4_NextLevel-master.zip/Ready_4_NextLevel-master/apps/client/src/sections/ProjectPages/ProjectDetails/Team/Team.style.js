import styled from "styled-components"; 

const TeamStyleWrapper = styled.section`
  background-color: #090a1a;  

  .section_title {
    text-align: center;
    margin-bottom: 55px;
  }
`;

export default TeamStyleWrapper;
