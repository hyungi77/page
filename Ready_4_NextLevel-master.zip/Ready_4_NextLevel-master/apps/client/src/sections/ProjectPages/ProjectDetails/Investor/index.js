import Partner from "./partner";

export default Partner;
