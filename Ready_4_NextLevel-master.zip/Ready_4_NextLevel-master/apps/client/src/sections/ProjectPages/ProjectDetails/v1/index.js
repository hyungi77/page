import ProjectDetails from "./ProjectDetails"

export default ProjectDetails;