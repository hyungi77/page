import CTA from "./CTA";

export default CTA;
