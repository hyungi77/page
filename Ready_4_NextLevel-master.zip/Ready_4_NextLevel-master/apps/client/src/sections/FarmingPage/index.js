import Farming from "./Farming";

export default Farming;
