import TeamDetails from "./TeamDetails"

export default TeamDetails;