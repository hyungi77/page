import Partner from "./partnet";

export default Partner;
