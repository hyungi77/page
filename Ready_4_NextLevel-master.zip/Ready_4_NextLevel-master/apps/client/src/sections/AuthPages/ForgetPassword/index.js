import ForgetPassword from "./ForgetPassword";

export default ForgetPassword;
