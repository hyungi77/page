import Allocation from "./Allocation";

export default Allocation;