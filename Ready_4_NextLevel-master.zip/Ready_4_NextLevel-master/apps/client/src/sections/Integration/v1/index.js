import Integration from "./Integration";

export default Integration;
