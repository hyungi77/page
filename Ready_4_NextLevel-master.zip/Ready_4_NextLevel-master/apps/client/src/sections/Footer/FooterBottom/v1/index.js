import FooterBottom from "./FooterBottom";

export default FooterBottom;