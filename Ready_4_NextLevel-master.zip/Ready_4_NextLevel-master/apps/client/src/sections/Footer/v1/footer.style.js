import styled from "styled-components";

const FooterStyleWrapper = styled.footer`
  position: relative;
  background: #090a1a;
`;

export default FooterStyleWrapper;
