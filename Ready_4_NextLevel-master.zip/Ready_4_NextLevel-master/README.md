# Ready_4_NextLevel

프로젝트 영문판 발표자료
[R4NL 최신본.pptx](https://github.com/hd3946/Ready_4_NextLevel/files/11561550/R4NL.pptx)
